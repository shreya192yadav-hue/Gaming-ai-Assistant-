package com.gameai.companion.vision

import android.graphics.Bitmap
import android.graphics.Color
import android.util.Base64
import java.io.ByteArrayOutputStream
import kotlin.math.abs

object VisionAnalyzer {
    private const val TW = 32
    private const val TH = 18

    /** Tiny brightness thumbnail used to detect meaningful screen change cheaply. */
    fun signature(bmp: Bitmap): IntArray {
        val t = Bitmap.createScaledBitmap(bmp, TW, TH, true)
        val px = IntArray(TW * TH)
        t.getPixels(px, 0, TW, 0, 0, TW, TH)
        return IntArray(px.size) { (Color.red(px[it]) * 3 + Color.green(px[it]) * 6 + Color.blue(px[it])) / 10 }
    }

    fun diff(a: IntArray, b: IntArray): Float {
        var s = 0L
        for (i in a.indices) s += abs(a[i] - b[i])
        return s / (a.size * 255f)
    }

    fun toJpegBase64(bmp: Bitmap, maxW: Int = 768): String {
        val scale = if (bmp.width > maxW) maxW.toFloat() / bmp.width else 1f
        val b = if (scale < 1f)
            Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true)
        else bmp
        val o = ByteArrayOutputStream()
        b.compress(Bitmap.CompressFormat.JPEG, 70, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }
}
