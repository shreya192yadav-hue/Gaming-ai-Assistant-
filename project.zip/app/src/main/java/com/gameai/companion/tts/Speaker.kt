package com.gameai.companion.tts

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class Speaker(ctx: Context, private val onProblem: (String) -> Unit) : TextToSpeech.OnInitListener {
    private val tts = TextToSpeech(ctx, this)
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var ready = false
    private var locale: Locale = Locale("hi", "IN")
    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()
    private val focus = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        .setAudioAttributes(attrs).build()

    override fun onInit(status: Int) {
        ready = status == TextToSpeech.SUCCESS
        if (!ready) { onProblem("Text-to-speech failed to start"); return }
        tts.setAudioAttributes(attrs)
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { am.abandonAudioFocusRequest(focus) }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { am.abandonAudioFocusRequest(focus) }
        })
    }

    fun setLocale(l: Locale) { locale = l }
    fun isSpeaking() = ready && tts.isSpeaking

    fun speak(text: String) {
        if (!ready) return
        val r = tts.setLanguage(locale)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            onProblem("This voice language is not installed. Download the Hindi voice in Settings > Google Text-to-speech.")
            return
        }
        am.requestAudioFocus(focus)
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u")
    }

    fun shutdown() { tts.stop(); tts.shutdown() }
}
