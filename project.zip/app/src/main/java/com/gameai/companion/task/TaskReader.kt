package com.gameai.companion.task

object TaskReader {
    fun system(lang: String) = """
You help a mobile gamer. You receive a game screenshot and OCR text.
Find the current mission / objective / quest shown on screen and state it in one or two short sentences.
If no objective is visible, say so briefly (or reply exactly SKIP if the player did not ask explicitly).
Reply ONLY in $lang. Plain spoken text, no emojis, no markdown.
""".trimIndent()
}
