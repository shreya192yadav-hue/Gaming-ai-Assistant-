package com.gameai.companion

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.gameai.companion.ai.AiProvider
import com.gameai.companion.capture.ScreenCapture
import com.gameai.companion.commentary.CommentaryEngine
import com.gameai.companion.context.GameContext
import com.gameai.companion.context.Mode
import com.gameai.companion.direction.DirectionEngine
import com.gameai.companion.events.EventManager
import com.gameai.companion.ocr.OcrEngine
import com.gameai.companion.settings.Settings
import com.gameai.companion.task.TaskReader
import com.gameai.companion.translation.Translator
import com.gameai.companion.tts.Speaker
import com.gameai.companion.vision.VisionAnalyzer
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class CaptureService : Service() {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private val main = Handler(Looper.getMainLooper())
    private lateinit var settings: Settings
    private lateinit var speaker: Speaker
    private lateinit var events: EventManager
    private val gameCtx = GameContext()
    private var capture: ScreenCapture? = null
    private var job: Job? = null
    @Volatile private var oneShot: Mode? = null
    private var lastToast = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_ASK -> {
                if (::events.isInitialized) {
                    oneShot = Mode.valueOf(intent.getStringExtra("mode") ?: "TASK")
                    events.forceNext = true
                }
                return START_NOT_STICKY
            }
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
        }
        if (intent == null || job != null) return START_NOT_STICKY

        settings = Settings(this)
        events = EventManager(settings)
        speaker = Speaker(this) { toast(it) }
        speaker.setLocale(Translator.locale(settings.language))

        startInForeground()

        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data")
        val code = intent.getIntExtra("code", 0)
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val projection: MediaProjection = mpm.getMediaProjection(code, data)
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, main)
        capture = ScreenCapture(this, projection, main).also { it.start() }
        job = scope.launch { loop() }
        AppState.setRunning(true)
        return START_NOT_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Game AI", NotificationManager.IMPORTANCE_LOW))
        fun act(label: String, mode: Mode, rc: Int) = NotificationCompat.Action.Builder(
            0, label,
            PendingIntent.getService(
                this, rc,
                Intent(this, CaptureService::class.java).setAction(ACTION_ASK).putExtra("mode", mode.name),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        ).build()
        val stop = NotificationCompat.Action.Builder(
            0, "Stop",
            PendingIntent.getService(
                this, 3, Intent(this, CaptureService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
        ).build()
        val n: Notification = NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Game AI is running")
            .setContentText("Tap a button below to ask")
            .setOngoing(true)
            .addAction(act("Read task", Mode.TASK, 1))
            .addAction(act("Get direction", Mode.GUIDE, 2))
            .addAction(stop)
            .build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private suspend fun loop() {
        while (currentCoroutineContext().isActive) {
            delay(1500)
            try {
                val bmp = capture?.grab() ?: continue
                if (speaker.isSpeaking()) continue
                val sig = VisionAnalyzer.signature(bmp)
                if (!events.shouldAnalyze(sig)) continue
                val forced = events.wasForced

                val mode = oneShot ?: Mode.valueOf(settings.mode)
                oneShot = null
                val lang = Translator.langName(settings.language)
                val system = when (mode) {
                    Mode.COMMENTARY -> CommentaryEngine.system(lang)
                    Mode.GUIDE -> DirectionEngine.system(lang)
                    Mode.TASK -> TaskReader.system(lang)
                }
                val ocr = OcrEngine.read(bmp)
                val user = buildString {
                    append("Things you already said recently: ").append(gameCtx.recent()).append('\n')
                    append("On-screen text (OCR): ").append(ocr.take(600)).append('\n')
                    if (forced) append("The player asked explicitly: always answer, never reply SKIP.")
                }
                val reply = AiProvider.ask(settings, system, user, if (settings.useImage) VisionAnalyzer.toJpegBase64(bmp) else null)
                if (reply.isBlank() || reply.trim().equals("SKIP", ignoreCase = true)) continue
                gameCtx.add(reply)
                AppState.addLine(reply, mode)
                speaker.setLocale(Translator.locale(settings.language))
                withContext(Dispatchers.Main) { speaker.speak(reply) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                toast("Error: ${e.message}")
                delay(10000)
            }
        }
    }

    private fun toast(msg: String) {
        val now = System.currentTimeMillis()
        if (now - lastToast < 20000) return
        lastToast = now
        main.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    override fun onDestroy() {
        scope.cancel()
        AppState.setRunning(false)
        capture?.stop()
        if (::speaker.isInitialized) speaker.shutdown()
        super.onDestroy()
    }

    companion object {
        const val CH = "gameai"
        const val ACTION_ASK = "com.gameai.companion.ASK"
        const val ACTION_STOP = "com.gameai.companion.STOP"
    }
}
