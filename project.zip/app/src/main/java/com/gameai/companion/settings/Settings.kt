package com.gameai.companion.settings

import android.content.Context

class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("gameai", Context.MODE_PRIVATE)
    var apiKey: String
        get() = p.getString("key", "") ?: ""
        set(v) = p.edit().putString("key", v).apply()
    /** "claude" or "openai" (any OpenAI-compatible service: OpenAI, OpenRouter, Groq, Gemini...) */
    var provider: String
        get() = p.getString("provider", "openai") ?: "openai"
        set(v) = p.edit().putString("provider", v).apply()
    var baseUrl: String
        get() = p.getString("base", "https://openrouter.ai/api/v1") ?: ""
        set(v) = p.edit().putString("base", v).apply()
    var model: String
        get() = p.getString("model", "") ?: ""
        set(v) = p.edit().putString("model", v).apply()
    var useImage: Boolean
        get() = p.getBoolean("img", true)
        set(v) = p.edit().putBoolean("img", v).apply()
    var language: String            // "hi" or "en"
        get() = p.getString("lang", "hi") ?: "hi"
        set(v) = p.edit().putString("lang", v).apply()
    var mode: String                // COMMENTARY / GUIDE / TASK
        get() = p.getString("mode", "COMMENTARY") ?: "COMMENTARY"
        set(v) = p.edit().putString("mode", v).apply()
    var minIntervalSec: Int
        get() = p.getInt("interval", 8)
        set(v) = p.edit().putInt("interval", v).apply()

    companion object { const val DEFAULT_CLAUDE_MODEL = "claude-haiku-4-5-20251001" }
}
