package com.gameai.companion.ai

import com.gameai.companion.settings.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** One place that talks to the AI. Supports Claude and any OpenAI-compatible service. */
object AiProvider {
    fun ask(settings: Settings, system: String, userText: String, jpegBase64: String?): String =
        if (settings.provider == "claude") askClaude(settings, system, userText, jpegBase64)
        else askOpenAiCompatible(settings, system, userText, jpegBase64)

    private fun askClaude(s: Settings, system: String, userText: String, img: String?): String {
        val content = JSONArray()
        if (img != null) {
            content.put(JSONObject().put("type", "image").put("source",
                JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", img)))
        }
        content.put(JSONObject().put("type", "text").put("text", userText))
        val body = JSONObject()
            .put("model", s.model.ifEmpty { Settings.DEFAULT_CLAUDE_MODEL })
            .put("max_tokens", 200)
            .put("system", system)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", content)))
        val text = post(
            "https://api.anthropic.com/v1/messages", body,
            mapOf("x-api-key" to s.apiKey, "anthropic-version" to "2023-06-01")
        )
        val arr = JSONObject(text).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("type") == "text") sb.append(o.getString("text")).append(' ')
        }
        return sb.toString().trim()
    }

    private fun askOpenAiCompatible(s: Settings, system: String, userText: String, img: String?): String {
        val content = JSONArray()
        content.put(JSONObject().put("type", "text").put("text", userText))
        if (img != null) {
            content.put(JSONObject().put("type", "image_url").put("image_url",
                JSONObject().put("url", "data:image/jpeg;base64,$img")))
        }
        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content", system))
            .put(JSONObject().put("role", "user").put("content", content))
        val body = JSONObject().put("model", s.model).put("messages", messages)
        val url = s.baseUrl.trimEnd('/') + "/chat/completions"
        val text = post(url, body, mapOf("Authorization" to "Bearer ${s.apiKey}"))
        return JSONObject(text).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").optString("content").trim()
    }

    private fun post(url: String, body: JSONObject, headers: Map<String, String>): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 15000
        conn.readTimeout = 40000
        conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader().use { it.readText() }
        if (code !in 200..299) throw IOException("API error $code: ${text.take(160)}")
        return text
    }
}
