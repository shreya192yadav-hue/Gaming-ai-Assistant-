package com.gameai.companion.translation

import java.util.Locale

/** The AI writes directly in the chosen language, so translation is done in the prompt. */
object Translator {
    fun langName(code: String) = if (code == "hi") "Hindi (Devanagari script)" else "English"
    fun locale(code: String): Locale = if (code == "hi") Locale("hi", "IN") else Locale.US
}
