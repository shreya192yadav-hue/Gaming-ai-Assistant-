package com.gameai.companion.ui

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView

/** Hacker / terminal look: black background, green monospace text. */
object Ui {
    val BG = Color.parseColor("#020402")
    val CARD = Color.parseColor("#050F05")
    val STROKE = Color.parseColor("#0F5F1F")
    val ACCENT = Color.parseColor("#00FF41")
    val ACCENT2 = Color.parseColor("#00C030")
    val ACCENT_DIM = Color.parseColor("#062B0E")
    val TEXT = Color.parseColor("#C8FFC8")
    val MUTED = Color.parseColor("#4F9A57")
    val OFF = Color.parseColor("#2A3D2C")

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun box(c: Context, fill: Int, stroke: Int, radiusDp: Int, strokeDp: Int = 1): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(fill)
        d.cornerRadius = dp(c, minOf(radiusDp, 6)).toFloat()
        d.setStroke(dp(c, strokeDp), stroke)
        return d
    }

    fun text(c: Context, t: String, sp: Float, color: Int, bold: Boolean = false): TextView {
        val tv = TextView(c)
        tv.text = t
        tv.textSize = sp
        tv.setTextColor(color)
        tv.setTypeface(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
        return tv
    }

    fun params(c: Context, topDp: Int = 12): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        p.topMargin = dp(c, topDp)
        return p
    }

    /** A bordered terminal panel with a small green title and a body view. */
    fun card(c: Context, title: String, body: View): LinearLayout {
        val box = LinearLayout(c)
        box.orientation = LinearLayout.VERTICAL
        box.background = box(c, CARD, STROKE, 4, 1)
        box.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 14))
        val t = text(c, title, 12f, ACCENT, true)
        box.addView(t)
        box.addView(body, params(c, 8))
        return box
    }

    /** Selectable buttons. If scroll is true the row scrolls sideways (for many options). */
    fun chips(c: Context, options: List<String>, selected: Int, scroll: Boolean = false, onPick: (Int) -> Unit): View {
        val row = LinearLayout(c)
        row.orientation = LinearLayout.HORIZONTAL
        val views = ArrayList<TextView>()
        var sel = selected
        fun paint() {
            for (i in views.indices) {
                val tv = views[i]
                if (i == sel) {
                    tv.background = box(c, ACCENT_DIM, ACCENT, 4, 2)
                    tv.setTextColor(ACCENT)
                } else {
                    tv.background = box(c, CARD, STROKE, 4, 1)
                    tv.setTextColor(MUTED)
                }
            }
        }
        for (i in options.indices) {
            val tv = TextView(c)
            tv.text = options[i]
            tv.gravity = Gravity.CENTER
            tv.textSize = 12f
            tv.setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
            tv.setPadding(dp(c, 8), dp(c, 12), dp(c, 8), dp(c, 12))
            val lp = if (scroll)
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            else
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            lp.setMargins(dp(c, 3), 0, dp(c, 3), 0)
            tv.layoutParams = lp
            tv.setOnClickListener {
                sel = i
                paint()
                onPick(i)
            }
            views.add(tv)
            row.addView(tv)
        }
        paint()
        if (!scroll) return row
        val sv = HorizontalScrollView(c)
        sv.isHorizontalScrollBarEnabled = false
        sv.addView(row)
        return sv
    }

    fun field(c: Context, hint: String, value: String, secret: Boolean = false, number: Boolean = false): EditText {
        val e = EditText(c)
        e.hint = hint
        e.setText(value)
        e.setTextColor(ACCENT)
        e.setHintTextColor(MUTED)
        e.setTypeface(Typeface.MONOSPACE)
        e.background = box(c, CARD, STROKE, 4, 1)
        e.setPadding(dp(c, 12), dp(c, 12), dp(c, 12), dp(c, 12))
        e.inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        else if (number) InputType.TYPE_CLASS_NUMBER
        else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        return e
    }
}
