package com.gameai.companion.voice

/** TODO (next step): voice commands such as "task बताओ" / "Get direction" using SpeechRecognizer. */
object VoiceInput
