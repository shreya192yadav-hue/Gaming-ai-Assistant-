package com.gameai.companion.context

enum class Mode { COMMENTARY, GUIDE, TASK }

/** Remembers what the AI said recently so it does not repeat itself. */
class GameContext {
    private val history = ArrayDeque<String>()
    fun add(line: String) {
        history.addLast(line)
        while (history.size > 5) history.removeFirst()
    }
    fun recent(): String = if (history.isEmpty()) "(nothing yet)" else history.joinToString(" | ")
}
