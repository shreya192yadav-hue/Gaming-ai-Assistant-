package com.gameai.companion.events

import android.os.SystemClock
import com.gameai.companion.settings.Settings
import com.gameai.companion.vision.VisionAnalyzer

/** Decides WHEN to call the AI, so we do not react to every frame (saves battery, latency and API cost). */
class EventManager(private val settings: Settings) {
    private var lastSig: IntArray? = null
    private var lastAnalyzed = 0L
    @Volatile var forceNext = false
    @Volatile var wasForced = false

    fun shouldAnalyze(sig: IntArray): Boolean {
        val now = SystemClock.elapsedRealtime()
        wasForced = false
        if (forceNext) {
            forceNext = false; wasForced = true
            lastSig = sig; lastAnalyzed = now
            return true
        }
        val prev = lastSig
        if (prev == null) { lastSig = sig; lastAnalyzed = now; return true }
        val changed = VisionAnalyzer.diff(prev, sig) > CHANGE_THRESHOLD
        val waited = now - lastAnalyzed >= settings.minIntervalSec * 1000L
        if (changed && waited) { lastSig = sig; lastAnalyzed = now; return true }
        return false
    }

    companion object { const val CHANGE_THRESHOLD = 0.06f }
}
