package com.gameai.companion

import android.os.Handler
import android.os.Looper
import com.gameai.companion.context.Mode

/** Small shared state so the dashboard can show what the background service is doing. */
object AppState {
    @Volatile var running = false
    @Volatile var currentTask = ""
    private val history = ArrayDeque<String>()
    var listener: (() -> Unit)? = null
    private val main = Handler(Looper.getMainLooper())

    fun setRunning(v: Boolean) { running = v; changed() }

    fun addLine(line: String, mode: Mode) {
        synchronized(this) {
            history.addFirst(line)
            while (history.size > 5) history.removeLast()
        }
        if (mode == Mode.TASK) currentTask = line
        changed()
    }

    fun lines(): List<String> = synchronized(this) { history.toList() }

    private fun changed() { main.post { listener?.invoke() } }
}
