package com.gameai.companion

import android.os.Bundle
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.appcompat.app.AppCompatActivity
import com.gameai.companion.settings.Settings
import com.gameai.companion.ui.Ui

class SettingsActivity : AppCompatActivity() {
    private lateinit var settings: Settings
    private lateinit var key: EditText
    private lateinit var base: EditText
    private lateinit var model: EditText
    private lateinit var interval: EditText

    private val presets = listOf("GEMINI", "OPENROUTER", "OPENAI", "GROQ", "CLAUDE", "CUSTOM")
    private val urls = listOf(
        "https://generativelanguage.googleapis.com/v1beta/openai",
        "https://openrouter.ai/api/v1",
        "https://api.openai.com/v1",
        "https://api.groq.com/openai/v1",
        "",
        ""
    )
    private val modelHints = listOf(
        "e.g. gemini-2.5-flash (see aistudio.google.com)",
        "e.g. provider/model-name (see openrouter.ai/models)",
        "e.g. gpt-4o-mini",
        "a vision model id from console.groq.com",
        "empty = claude-haiku-4-5-20251001",
        "model id of your API"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = Settings(this)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        val c = this
        val root = LinearLayout(c)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.setPadding(Ui.dp(c, 18), Ui.dp(c, 22), Ui.dp(c, 18), Ui.dp(c, 28))

        key = Ui.field(c, "API key", settings.apiKey, secret = true)
        base = Ui.field(c, "https://.../v1", settings.baseUrl)
        model = Ui.field(c, "model id", settings.model)
        interval = Ui.field(c, "8", settings.minIntervalSec.toString(), number = true)

        var current = 5
        if (settings.provider == "claude") current = 4
        else {
            val b = settings.baseUrl
            if (b.contains("googleapis")) current = 0
            else if (b.contains("openrouter")) current = 1
            else if (b.contains("openai.com")) current = 2
            else if (b.contains("groq")) current = 3
        }
        model.hint = modelHints[current]

        root.addView(Ui.text(c, "SETTINGS//", 22f, Ui.ACCENT, true))

        root.addView(Ui.text(c, "> API_PROVIDER", 12f, Ui.ACCENT, true), Ui.params(c, 22))
        root.addView(Ui.chips(c, presets, current, true) { i ->
            settings.provider = if (i == 4) "claude" else "openai"
            if (i in 0..3) base.setText(urls[i])
            model.hint = modelHints[i]
        }, Ui.params(c, 8))
        root.addView(
            Ui.text(c, "Any OpenAI-compatible API works: pick CUSTOM and type its base URL.", 11f, Ui.MUTED),
            Ui.params(c, 6)
        )

        root.addView(Ui.text(c, "> API_KEY", 12f, Ui.ACCENT, true), Ui.params(c, 18))
        root.addView(key, Ui.params(c, 8))

        root.addView(Ui.text(c, "> BASE_URL (not used for CLAUDE)", 12f, Ui.ACCENT, true), Ui.params(c, 18))
        root.addView(base, Ui.params(c, 8))

        root.addView(Ui.text(c, "> MODEL", 12f, Ui.ACCENT, true), Ui.params(c, 18))
        root.addView(model, Ui.params(c, 8))

        root.addView(Ui.text(c, "> SEND_SCREENSHOT (model must understand images)", 12f, Ui.ACCENT, true), Ui.params(c, 18))
        root.addView(Ui.chips(c, listOf("YES", "NO"), if (settings.useImage) 0 else 1) {
            settings.useImage = it == 0
        }, Ui.params(c, 8))

        root.addView(Ui.text(c, "> VOICE_LANG", 12f, Ui.ACCENT, true), Ui.params(c, 18))
        root.addView(Ui.chips(c, listOf("HINDI", "ENGLISH"), if (settings.language == "hi") 0 else 1) {
            settings.language = if (it == 0) "hi" else "en"
        }, Ui.params(c, 8))

        root.addView(Ui.text(c, "> MIN_SECONDS_BETWEEN_VOICE_LINES", 12f, Ui.ACCENT, true), Ui.params(c, 18))
        root.addView(interval, Ui.params(c, 8))

        val save = Ui.text(c, "[ SAVE & BACK ]", 15f, Ui.ACCENT, true)
        save.gravity = Gravity.CENTER
        save.background = Ui.box(c, Ui.ACCENT_DIM, Ui.ACCENT, 4, 2)
        save.setPadding(0, Ui.dp(c, 14), 0, Ui.dp(c, 14))
        save.setOnClickListener { finish() }
        root.addView(save, Ui.params(c, 26))

        val sv = ScrollView(c)
        sv.setBackgroundColor(Ui.BG)
        sv.addView(root)
        setContentView(sv)
    }

    override fun onPause() {
        settings.apiKey = key.text.toString().trim()
        settings.baseUrl = base.text.toString().trim()
        settings.model = model.text.toString().trim()
        settings.minIntervalSec = interval.text.toString().toIntOrNull()?.coerceIn(3, 60) ?: 8
        super.onPause()
    }
}
