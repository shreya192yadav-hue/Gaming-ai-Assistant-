package com.gameai.companion

import android.Manifest
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.gameai.companion.context.Mode
import com.gameai.companion.settings.Settings
import com.gameai.companion.ui.Ui

class MainActivity : AppCompatActivity() {
    private lateinit var settings: Settings
    private var pill: TextView? = null
    private var power: TextView? = null
    private var say: TextView? = null
    private var task: TextView? = null
    private var history: TextView? = null

    private val capLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            val i = Intent(this, CaptureService::class.java)
                .putExtra("code", r.resultCode).putExtra("data", data)
            ContextCompat.startForegroundService(this, i)
            Toast.makeText(this, "Running. Now open your game.", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(this, "Screen capture permission was not granted.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settings = Settings(this)
        window.statusBarColor = Ui.BG
        window.navigationBarColor = Ui.BG
        if (Build.VERSION.SDK_INT >= 33) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun buildUi() {
        val c = this
        val root = LinearLayout(c)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Ui.BG)
        root.setPadding(Ui.dp(c, 18), Ui.dp(c, 22), Ui.dp(c, 18), Ui.dp(c, 28))

        val header = LinearLayout(c)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val title = Ui.text(c, "GAME_AI//", 22f, Ui.ACCENT, true)
        title.layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        header.addView(title)
        val p = TextView(c)
        p.textSize = 12f
        p.setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
        p.setPadding(Ui.dp(c, 10), Ui.dp(c, 6), Ui.dp(c, 10), Ui.dp(c, 6))
        header.addView(p)
        pill = p
        root.addView(header)
        root.addView(Ui.text(c, "root@game-ai:~\$ status_", 12f, Ui.MUTED), Ui.params(c, 4))

        val pw = TextView(c)
        pw.text = "⏻"
        pw.textSize = 52f
        pw.gravity = Gravity.CENTER
        val pwp = LinearLayout.LayoutParams(Ui.dp(c, 140), Ui.dp(c, 140))
        pwp.gravity = Gravity.CENTER_HORIZONTAL
        pwp.topMargin = Ui.dp(c, 26)
        pwp.bottomMargin = Ui.dp(c, 8)
        pw.layoutParams = pwp
        pw.elevation = Ui.dp(c, 16).toFloat()
        if (Build.VERSION.SDK_INT >= 28) {
            pw.outlineAmbientShadowColor = Ui.ACCENT
            pw.outlineSpotShadowColor = Ui.ACCENT
        }
        pw.setOnClickListener { togglePower() }
        root.addView(pw)
        power = pw

        val s = Ui.text(c, "", 15f, Ui.TEXT)
        val t = Ui.text(c, "", 14f, Ui.TEXT)
        val h = Ui.text(c, "", 12f, Ui.MUTED)
        say = s; task = t; history = h
        root.addView(Ui.card(c, "> AI_OUTPUT", s), Ui.params(c, 18))
        root.addView(Ui.card(c, "> CURRENT_TASK", t), Ui.params(c))

        root.addView(Ui.text(c, "> MODE", 12f, Ui.ACCENT, true), Ui.params(c, 20))
        root.addView(Ui.chips(c, listOf("COMMENTARY", "GUIDE", "TASK"), Mode.valueOf(settings.mode).ordinal) {
            settings.mode = Mode.values()[it].name
        }, Ui.params(c, 8))

        root.addView(Ui.text(c, "> VOICE_LANG", 12f, Ui.ACCENT, true), Ui.params(c, 18))
        root.addView(Ui.chips(c, listOf("HINDI", "ENGLISH"), if (settings.language == "hi") 0 else 1) {
            settings.language = if (it == 0) "hi" else "en"
        }, Ui.params(c, 8))

        root.addView(Ui.card(c, "> LOG", h), Ui.params(c, 20))

        val sb = Ui.text(c, "[ SETTINGS ]", 15f, Ui.ACCENT, true)
        sb.gravity = Gravity.CENTER
        sb.background = Ui.box(c, Ui.CARD, Ui.ACCENT2, 4, 2)
        sb.setPadding(0, Ui.dp(c, 14), 0, Ui.dp(c, 14))
        sb.setOnClickListener { startActivity(Intent(c, SettingsActivity::class.java)) }
        root.addView(sb, Ui.params(c, 20))

        val sv = ScrollView(c)
        sv.setBackgroundColor(Ui.BG)
        sv.addView(root)
        setContentView(sv)
    }

    private fun togglePower() {
        if (AppState.running) {
            stopService(Intent(this, CaptureService::class.java))
            AppState.setRunning(false)
            return
        }
        val needSetup = settings.apiKey.isEmpty() ||
            (settings.provider != "claude" && (settings.model.isEmpty() || settings.baseUrl.isEmpty()))
        if (needSetup) {
            Toast.makeText(this, "First enter the API key, base URL and model in Settings.", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        capLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun refresh() {
        val c = this
        val on = AppState.running
        val pl = pill ?: return
        val pw = power ?: return
        pl.text = if (on) "[ ACTIVE ]" else "[ OFFLINE ]"
        pl.setTextColor(if (on) Ui.ACCENT else Ui.MUTED)
        pl.background = Ui.box(c, if (on) Ui.ACCENT_DIM else Ui.CARD, if (on) Ui.ACCENT else Ui.OFF, 4, 1)
        pw.setTextColor(if (on) Ui.ACCENT else Ui.OFF)
        val g = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            if (on) intArrayOf(Ui.ACCENT_DIM, Ui.BG) else intArrayOf(Ui.CARD, Ui.BG)
        )
        g.shape = GradientDrawable.OVAL
        g.setStroke(Ui.dp(c, 3), if (on) Ui.ACCENT else Ui.OFF)
        pw.background = g
        val lines = AppState.lines()
        say?.text = if (lines.isEmpty()) "> no output yet. tap the power button." else "> " + lines[0]
        task?.text = if (AppState.currentTask.isEmpty()) "> no task detected yet. use 'Read task' in the notification." else "> " + AppState.currentTask
        history?.text = if (lines.isEmpty()) "-" else lines.joinToString("\n\n") { "\$ $it" }
    }

    override fun onResume() {
        super.onResume()
        buildUi()
        AppState.listener = { refresh() }
        refresh()
    }

    override fun onPause() {
        AppState.listener = null
        super.onPause()
    }
}
