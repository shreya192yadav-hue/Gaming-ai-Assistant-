package com.gameai.companion.recording

/** TODO (later): save gameplay + AI commentary as a video. */
object Recorder
