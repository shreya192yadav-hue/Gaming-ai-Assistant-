package com.gameai.companion.capture

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.util.DisplayMetrics
import android.view.WindowManager

class ScreenCapture(
    private val ctx: Context,
    private val projection: MediaProjection,
    private val handler: Handler
) {
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var w = 0
    private var h = 0
    private var last: Bitmap? = null
    private val dpi = ctx.resources.displayMetrics.densityDpi

    private fun realSize(): Pair<Int, Int> {
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(dm)
        return Pair((dm.widthPixels * SCALE).toInt(), (dm.heightPixels * SCALE).toInt())
    }

    fun start() {
        val (nw, nh) = realSize()
        w = nw; h = nh
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        display = projection.createVirtualDisplay(
            "gameai", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, handler
        )
    }

    /** Latest frame (or the previous one if the screen has not changed). */
    fun grab(): Bitmap? {
        val (nw, nh) = realSize()
        if (nw != w || nh != h) {          // screen rotated
            w = nw; h = nh
            val old = reader
            val nr = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            reader = nr
            display?.resize(w, h, dpi)
            display?.surface = nr.surface
            old?.close()
            last = null
        }
        val img = reader?.acquireLatestImage() ?: return last
        try {
            val plane = img.planes[0]
            val rowPadding = plane.rowStride - plane.pixelStride * w
            val full = Bitmap.createBitmap(w + rowPadding / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)
            last = Bitmap.createBitmap(full, 0, 0, w, h)
        } finally {
            img.close()
        }
        return last
    }

    fun stop() {
        display?.release()
        reader?.close()
        projection.stop()
    }

    companion object { const val SCALE = 0.5f }
}
